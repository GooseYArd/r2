#ifndef _VERSION_H_
#define _VERSION_H_
#define REPMGR_VERSION "1.2.0"
#endif
